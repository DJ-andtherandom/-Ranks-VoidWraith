package com.voidwraith.ranks;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class VoidWraithRanks extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {

    private static final String ADMIN = "voidwraithranks.admin";

    private static final LegacyComponentSerializer LEGACY =
            LegacyComponentSerializer.builder().character('&').hexColors().build();

    /** Marks our menu so we can recognise it in click events. */
    private static final class RanksMenu implements InventoryHolder {
        private Inventory inventory;
        private final Map<Integer, Boolean> owned = new HashMap<>();

        @Override
        public @NotNull Inventory getInventory() {
            return inventory;
        }
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("ranks") != null) {
            getCommand("ranks").setExecutor(this);
            getCommand("ranks").setTabCompleter(this);
        }
        if (getCommand("voidwraithranks") != null) {
            getCommand("voidwraithranks").setExecutor(this);
        }
    }

    private Component text(String s) {
        return LEGACY.deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    // ------------------------------------------------------------------
    // Commands
    // ------------------------------------------------------------------

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (command.getName().equalsIgnoreCase("voidwraithranks")) {
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                reloadConfig();
                sender.sendMessage(text("&aVoidWraithRanks config reloaded."));
            } else {
                sender.sendMessage(text("&7Usage: /voidwraithranks reload"));
            }
            return true;
        }

        // /ranks  -> open menu
        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Only players can open the ranks menu.");
                return true;
            }
            openMenu(player);
            return true;
        }

        // /ranks <subcommand> ... -> admin only
        if (!sender.hasPermission(ADMIN)) {
            sender.sendMessage(text("&cYou don't have permission to do that."));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "give", "take" -> handleGiveTake(sender, args);
            case "edit" -> handleEdit(sender, args);
            case "add" -> handleAdd(sender, args);
            case "remove" -> handleRemove(sender, args);
            default -> sendUsage(sender);
        }
        return true;
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(text("&#9D6BD6&lVoidWraithRanks &7commands:"));
        sender.sendMessage(text("&7/ranks &8- &fopen the menu"));
        sender.sendMessage(text("&7/ranks give <player> <rank>"));
        sender.sendMessage(text("&7/ranks take <player> <rank>"));
        sender.sendMessage(text("&7/ranks edit <rank> <name|icon|slot|lore> <value>"));
        sender.sendMessage(text("&7/ranks add <rank>  &8|  &7/ranks remove <rank>"));
    }

    private boolean isValidPlayerName(String name) {
        return name.matches("[A-Za-z0-9_.]{1,16}");
    }

    private boolean isValidRankKey(String key) {
        return key.matches("[a-z0-9_-]{1,32}");
    }

    private ConfigurationSection rankSection(String key) {
        ConfigurationSection ranks = getConfig().getConfigurationSection("ranks");
        return ranks == null ? null : ranks.getConfigurationSection(key);
    }

    private void handleGiveTake(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(text("&7Usage: /ranks " + args[0].toLowerCase() + " <player> <rank>"));
            return;
        }
        String player = args[1];
        String rank = args[2].toLowerCase();

        if (!isValidPlayerName(player)) {
            sender.sendMessage(text("&cThat doesn't look like a valid player name."));
            return;
        }
        if (rankSection(rank) == null) {
            sender.sendMessage(text("&cUnknown rank &f" + rank + "&c. Check the ranks in config.yml."));
            return;
        }
        if (Bukkit.getPluginManager().getPlugin("LuckPerms") == null) {
            sender.sendMessage(text("&cLuckPerms isn't installed, so I can't change ranks."));
            return;
        }

        boolean give = args[0].equalsIgnoreCase("give");
        String lp = "lp user " + player + (give ? " parent add " : " parent remove ") + rank;
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), lp);
        sender.sendMessage(text("&aRan: &f" + lp));
    }

    private void handleEdit(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(text("&7Usage: /ranks edit <rank> <name|icon|slot|lore> <value>"));
            return;
        }
        String rank = args[1].toLowerCase();
        String path = "ranks." + rank;
        if (rankSection(rank) == null) {
            sender.sendMessage(text("&cUnknown rank &f" + rank + "&c."));
            return;
        }

        String field = args[2].toLowerCase();
        String value = String.join(" ", Arrays.copyOfRange(args, 3, args.length));

        switch (field) {
            case "name" -> getConfig().set(path + ".name", value);
            case "icon" -> {
                Material m = Material.matchMaterial(value);
                if (m == null || !m.isItem()) {
                    sender.sendMessage(text("&cThat isn't a valid item. Example: NETHER_STAR"));
                    return;
                }
                getConfig().set(path + ".icon", m.name());
            }
            case "slot" -> {
                int max = Math.max(1, Math.min(6, getConfig().getInt("rows", 3))) * 9;
                try {
                    int slot = Integer.parseInt(value.trim());
                    if (slot < 0 || slot >= max) {
                        sender.sendMessage(text("&cSlot must be between 0 and " + (max - 1) + "."));
                        return;
                    }
                    getConfig().set(path + ".slot", slot);
                } catch (NumberFormatException ex) {
                    sender.sendMessage(text("&cSlot must be a number."));
                    return;
                }
            }
            case "lore" -> {
                List<String> lines = new ArrayList<>();
                for (String part : value.split("\\|")) {
                    lines.add(part.trim());
                }
                getConfig().set(path + ".lore", lines);
            }
            default -> {
                sender.sendMessage(text("&cYou can edit: name, icon, slot, lore."));
                return;
            }
        }
        saveConfig();
        sender.sendMessage(text("&aUpdated &f" + field + " &afor rank &f" + rank + "&a."));
    }

    private void handleAdd(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(text("&7Usage: /ranks add <rank>  (rank = the LuckPerms group name)"));
            return;
        }
        String rank = args[1].toLowerCase();
        if (!isValidRankKey(rank)) {
            sender.sendMessage(text("&cUse only letters, numbers, - and _ for the rank name."));
            return;
        }
        if (rankSection(rank) != null) {
            sender.sendMessage(text("&cThat rank is already in the menu."));
            return;
        }

        int max = Math.max(1, Math.min(6, getConfig().getInt("rows", 3))) * 9;
        Set<Integer> used = new HashSet<>();
        ConfigurationSection ranks = getConfig().getConfigurationSection("ranks");
        if (ranks != null) {
            for (String key : ranks.getKeys(false)) {
                used.add(ranks.getInt(key + ".slot", -1));
            }
        }
        int slot = -1;
        for (int i = 0; i < max; i++) {
            if (!used.contains(i)) {
                slot = i;
                break;
            }
        }
        if (slot == -1) {
            sender.sendMessage(text("&cThe menu is full. Increase 'rows' in config.yml."));
            return;
        }

        String path = "ranks." + rank;
        getConfig().set(path + ".name", "&7" + rank);
        getConfig().set(path + ".icon", "AMETHYST_SHARD");
        getConfig().set(path + ".slot", slot);
        getConfig().set(path + ".lore", new ArrayList<String>());
        saveConfig();
        sender.sendMessage(text("&aAdded rank &f" + rank + " &ain slot " + slot + ". Use /ranks edit to style it."));
    }

    private void handleRemove(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(text("&7Usage: /ranks remove <rank>"));
            return;
        }
        String rank = args[1].toLowerCase();
        if (rankSection(rank) == null) {
            sender.sendMessage(text("&cUnknown rank &f" + rank + "&c."));
            return;
        }
        getConfig().set("ranks." + rank, null);
        saveConfig();
        sender.sendMessage(text("&aRemoved &f" + rank + " &afrom the menu (the LuckPerms group is untouched)."));
    }

    // ------------------------------------------------------------------
    // Tab completion
    // ------------------------------------------------------------------

    private List<String> rankKeys() {
        ConfigurationSection ranks = getConfig().getConfigurationSection("ranks");
        return ranks == null ? new ArrayList<>() : new ArrayList<>(ranks.getKeys(false));
    }

    private List<String> filter(List<String> options, String prefix) {
        List<String> out = new ArrayList<>();
        for (String o : options) {
            if (o.toLowerCase().startsWith(prefix.toLowerCase())) {
                out.add(o);
            }
        }
        return out;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String alias, @NotNull String[] args) {
        if (!command.getName().equalsIgnoreCase("ranks") || !sender.hasPermission(ADMIN)) {
            return new ArrayList<>();
        }
        List<String> options = new ArrayList<>();
        if (args.length == 1) {
            options = Arrays.asList("give", "take", "edit", "add", "remove");
        } else if (args.length == 2) {
            switch (args[0].toLowerCase()) {
                case "give", "take" -> {
                    for (Player p : Bukkit.getOnlinePlayers()) {
                        options.add(p.getName());
                    }
                }
                case "edit", "remove" -> options = rankKeys();
                default -> { }
            }
        } else if (args.length == 3) {
            switch (args[0].toLowerCase()) {
                case "give", "take" -> options = rankKeys();
                case "edit" -> options = Arrays.asList("name", "icon", "slot", "lore");
                default -> { }
            }
        }
        return filter(options, args[args.length - 1]);
    }

    // ------------------------------------------------------------------
    // Menu
    // ------------------------------------------------------------------

    private void openMenu(Player player) {
        int rows = Math.max(1, Math.min(6, getConfig().getInt("rows", 3)));
        RanksMenu holder = new RanksMenu();
        Inventory inv = Bukkit.createInventory(holder, rows * 9,
                text(getConfig().getString("menu-title", "&#9D6BD6&lRanks")));
        holder.inventory = inv;

        Material ownedMaterial = Material.matchMaterial(
                getConfig().getString("owned-material", "PAPER"));
        if (ownedMaterial == null) {
            ownedMaterial = Material.PAPER;
        }

        ConfigurationSection ranks = getConfig().getConfigurationSection("ranks");
        if (ranks != null) {
            for (String group : ranks.getKeys(false)) {
                ConfigurationSection r = ranks.getConfigurationSection(group);
                if (r == null) {
                    continue;
                }
                int slot = r.getInt("slot", -1);
                if (slot < 0 || slot >= inv.getSize()) {
                    continue;
                }

                boolean owned = player.hasPermission("group." + group.toLowerCase());
                String name = r.getString("name", group);

                Material icon = Material.matchMaterial(r.getString("icon", "AMETHYST_SHARD"));
                if (icon == null) {
                    icon = Material.AMETHYST_SHARD;
                }

                ItemStack item = new ItemStack(owned ? ownedMaterial : icon);
                ItemMeta meta = item.getItemMeta();
                if (owned) {
                    meta.displayName(text(name + getConfig().getString("owned-suffix", " &a(Owned)")));
                } else {
                    meta.displayName(text(name));
                }

                List<Component> lore = new ArrayList<>();
                for (String line : r.getStringList("lore")) {
                    lore.add(text(line));
                }
                lore.add(Component.empty());
                lore.add(text(owned
                        ? getConfig().getString("owned-line", "&aYou own this rank.")
                        : getConfig().getString("locked-line", "&cYou don't have this rank.")));
                meta.lore(lore);
                item.setItemMeta(meta);

                inv.setItem(slot, item);
                holder.owned.put(slot, owned);
            }
        }

        if (getConfig().getBoolean("filler.enabled", true)) {
            Material fillerMaterial = Material.matchMaterial(
                    getConfig().getString("filler.material", "BLACK_STAINED_GLASS_PANE"));
            if (fillerMaterial != null) {
                for (int i = 0; i < inv.getSize(); i++) {
                    if (inv.getItem(i) == null) {
                        ItemStack filler = new ItemStack(fillerMaterial);
                        ItemMeta fm = filler.getItemMeta();
                        fm.displayName(Component.text(" "));
                        filler.setItemMeta(fm);
                        inv.setItem(i, filler);
                    }
                }
            }
        }

        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof RanksMenu menu)) {
            return;
        }
        event.setCancelled(true);

        if (event.getClickedInventory() != top) {
            return;
        }
        Boolean owned = menu.owned.get(event.getSlot());
        if (owned != null && !owned && event.getWhoClicked() instanceof Player player) {
            String msg = getConfig().getString("locked-click-message", "");
            if (!msg.isEmpty()) {
                player.sendMessage(text(msg));
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof RanksMenu) {
            event.setCancelled(true);
        }
    }
}
