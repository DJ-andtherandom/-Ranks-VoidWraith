VoidWraithRanks - Paper plugin (source)

Commands
  /ranks                                   open the menu (everyone)
  /ranks give <player> <rank>              admin: lp user <player> parent add <rank>
  /ranks take <player> <rank>              admin: lp user <player> parent remove <rank>
  /ranks edit <rank> name <text>           admin: change the display name (& and &#RRGGBB colors)
  /ranks edit <rank> icon <MATERIAL>       admin: item shown when the player does NOT own it
  /ranks edit <rank> slot <number>         admin: menu slot
  /ranks edit <rank> lore <line|line|...>  admin: description lines, separated by |
  /ranks add <rank> / remove <rank>        admin: add/remove a rank in the menu
  /voidwraithranks reload                  admin: reload config.yml
Permissions: voidwraithranks.use (default everyone), voidwraithranks.admin (default op)

Ranks the player HAS show as PAPER. Ranks they do NOT have show as their icon.
Rank keys must match LuckPerms group names (lowercase). Needs Paper + LuckPerms.

HOW TO GET THE .JAR WITHOUT INSTALLING ANYTHING (GitHub)
  1. Make a free account at github.com and create a new repository.
  2. Upload everything from this folder (keep the folders, including .github).
     If the .github folder will not upload: Actions tab -> "set up a workflow yourself"
     -> paste the contents of .github/workflows/build.yml -> commit.
  3. Open the Actions tab -> the newest "Build VoidWraithRanks" run -> wait for the green check.
  4. Scroll to Artifacts and download "VoidWraithRanks" (a zip). Unzip it to get VoidWraithRanks-1.0.0.jar.

HOW TO BUILD LOCALLY (needs JDK 21 + Maven)
  mvn package   ->   target/VoidWraithRanks-1.0.0.jar

INSTALL ON CLOUDEXA
  Panel -> Files -> plugins -> Upload -> pick the .jar -> Restart.
  Edit plugins/VoidWraithRanks/config.yml afterwards if you want.
